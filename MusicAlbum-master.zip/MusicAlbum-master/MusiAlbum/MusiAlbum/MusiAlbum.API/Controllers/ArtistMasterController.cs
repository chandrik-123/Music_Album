﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MusiAlbum.Data.Models;
using MusiAlbum.Data.Service.Abstract;

namespace MusiAlbum.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArtistMasterController : ControllerBase
    {
        private readonly IArtsitMasterService _artsitMasterService;
        public ArtistMasterController(IArtsitMasterService artistMasterContext)
        {
            _artsitMasterService = artistMasterContext;
        }
        [HttpPost("SaveArtist")]
        public async Task<IActionResult> SaveArtist(ArtistMaster artistMaster)
        {
            var res = await _artsitMasterService.SaveArtistMaster(artistMaster);
          
            return Ok(new { status = 200, success = true, res });
        }
        [HttpPost("UpdateArtist")]
        public async Task<IActionResult> UpdteArtist(ArtistMaster artistMaster)
        {
            var res = await _artsitMasterService.UpdateArtistMaster(artistMaster);
            
            return Ok(new { res });
        }
        [HttpPost("DeleteArtist")]
        public async Task<IActionResult> DeleteArtist(ArtistMaster artistMaster)
        {
            var res = await _artsitMasterService.DeleteArtistMaster(artistMaster);

            return Ok(new { res });
        }
        [HttpGet("GetArtist")]
        public async Task<IActionResult> GetArtist()
        {
            var res = await _artsitMasterService.GetArtests();

            return Ok(new { res });
        }
        [HttpPost("MusicMaster")]
        public async Task<IActionResult> musicmaster(MusicMaster musicMaster)
        {
            var res = await _artsitMasterService.SaveMusicMaster(musicMaster);

            return Ok(new { res });
        }
        
        
               

        [Route("GetArtistTitle")]
        public async Task<IActionResult> GetArtistTitle(string artistname)
        {
            var res = await _artsitMasterService.GetArtistMasterBaseduponName(artistname);

            
            return Ok(new { status = 200, success = true, res });
        }
    }
}
