﻿using MusiAlbum.Data.Models;
using MusiAlbum.Data.Service.Derived;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MusiAlbum.Data.Service.Abstract
{
   public interface ITitleMaster
    {
        Task<string> SaveTitleMaster(TitleMasters title);
        Task<string> DeleteTitleMaster(TitleMasters title);
        Task<string> UpdateTitleMaster(TitleMasters title);
        //Task<List<TitleMasters>> GetTitles();
        Task<List<TitleMasters>> GetTitles();
        Task<TitleMasters> GetTitleMaster(int title_id);
        Task<ArtistMaster> SaveMusicMaster(TitleMasters title);
    }
}
