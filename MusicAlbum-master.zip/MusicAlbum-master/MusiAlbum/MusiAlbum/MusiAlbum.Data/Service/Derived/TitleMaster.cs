﻿using MusiAlbum.Data.Models;
using MusiAlbum.Data.Service.Abstract;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusiAlbum.Data.Service.Derived
{
    public class TitleMaster : ITitleMaster
    {
        private readonly IMySqlConnectionService _mySqlConnectionService;
        // private readonly MySqlConnectionService mySqlConnectionService;

        //public string Message { get; set; }

        public TitleMaster(IMySqlConnectionService mySqlConnectionService)
        {
            this._mySqlConnectionService = mySqlConnectionService;
            //mySqlConnectionService = sq;

        }

        public async Task<string> DeleteTitleMaster(TitleMasters title)
        {
            int inserted = 0;
            try
            {
                List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("ititleid", title.title_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("ititlename", title.title_name));

                mySqlParameters.Add(_mySqlConnectionService.GetParameterOut("oMessage", MySqlDbType.VarChar, null, ParameterDirection.Output));
                string messages = string.Empty;
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iQuery", 3));
                inserted = await _mySqlConnectionService.ExecuteNonQuery("Sp_InsertUpdateDeleteForTitleMaster", mySqlParameters).ConfigureAwait(false);
                return _mySqlConnectionService.Message;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<List<TitleMasters>> GetTitles()
        {
            List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
            List<TitleMasters> titleMasters = new List<TitleMasters>();
            TitleMasters titleMaster = null;
            try
            {
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iTitleid",null));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iQuery", 1));
                MySqlDataReader mySqlDataReader = await _mySqlConnectionService.GetDataReader("gettitles", mySqlParameters).ConfigureAwait(false);
                while (mySqlDataReader.Read())
                {
                    titleMaster = new TitleMasters
                    {
                        title_id = Convert.ToInt32(mySqlDataReader["title_id"]),
                        title_name = Convert.ToString(mySqlDataReader["title_name"])

                    };
                    titleMasters.Add(titleMaster);
                }



            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
            }
            return titleMasters;

        }


        public Task<string> SaveMusicMaster(TitleMasters title)
        {
            throw new NotImplementedException();
        }

        public async Task<string> SaveTitleMaster(TitleMasters title)
        {
            int inserted = 0;
            try
            {
                List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("ititleid", title.title_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("ititlename", title.title_name));
                // mySqlParameters.Add(_mySqlConnectionService.GetParameter("iprofession", artistMaster.profession));

                _mySqlConnectionService.OutParamName = "oMessage";
                mySqlParameters.Add(_mySqlConnectionService.GetParameterOut("oMessage", MySqlDbType.VarChar, null, ParameterDirection.Output));
                string messages = string.Empty;

                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iQuery", 1));
                inserted = await _mySqlConnectionService.ExecuteNonQuery("Sp_InsertUpdateDeleteForTitleMaster", mySqlParameters).ConfigureAwait(false);
                return _mySqlConnectionService.Message;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public async Task<string> UpdateTitleMaster(TitleMasters title)
        {
            int inserted = 0;
            try
            {
                List<MySqlParameter> mySqlParameters = new List<MySqlParameter>();
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("ititleid", title.title_id));
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("ititlename", title.title_name));
                mySqlParameters.Add(_mySqlConnectionService.GetParameterOut("oMessage", MySqlDbType.VarChar, null, ParameterDirection.Output));
                string messages = string.Empty;
                mySqlParameters.Add(_mySqlConnectionService.GetParameter("iQuery", 2));
                inserted = await _mySqlConnectionService.ExecuteNonQuery("Sp_InsertUpdateDeleteForTitleMaster", mySqlParameters).ConfigureAwait(false);
                return _mySqlConnectionService.Message;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        Task<TitleMasters> ITitleMaster.GetTitleMaster(int title_id)
        {
            throw new NotImplementedException();
        }

        Task<ArtistMaster> ITitleMaster.SaveMusicMaster(TitleMasters title)
        {
            throw new NotImplementedException();
        }
    }
}
