﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusiAlbum.Data.Models
{
    public class ArtistMaster
    {
        public int artist_id { get; set; }
        public string artist_name { get; set; }
        public string profession { get; set; }
        public int title_id { get; set; }

        public string title_name { get; set; }
      
    }
   
}
