# MusicAlbum
POC On MusicAlbum
In this Project we were used 3Tier Architecture,ASP.NET CORE3.1,WEB API and Frontend side we were used Angular.
Database MySql.
